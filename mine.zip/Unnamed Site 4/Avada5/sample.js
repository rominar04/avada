 $(document).ready(function(){
$('#responsive-menu').prmenu();
});

$(document).ready(function(){
$('#responsive-menu').prmenu({}
maintain_ratio: true,
link: '#000000',
visited: '#000000',
hover: '#666666',
active: '#666666',
current: '#444444');
});